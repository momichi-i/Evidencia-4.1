using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Navigation;

namespace CapibaraPortal;

public sealed partial class RegisterPage : Page
{
    public RegisterPage()
    {
        InitializeComponent();
    }

    // Si venimos del login, el usuario que se intentó usar llega ya escrito.
    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        if (e.Parameter is string user && !string.IsNullOrEmpty(user))
            UserBox.Text = user;
    }

    private void NoSpaces_BeforeTextChanging(TextBox sender, TextBoxBeforeTextChangingEventArgs args)
    {
        if (Validator.HasWhitespace(args.NewText))
            args.Cancel = true;
    }

    private void Password_PasswordChanged(object sender, RoutedEventArgs e)
    {
        if (Validator.HasWhitespace(PassBox.Password) || Validator.HasWhitespace(ConfirmBox.Password))
            ShowError("La contraseña no puede tener espacios.");
        else
            ErrorText.Visibility = Visibility.Collapsed;
    }

    private async void Field_KeyDown(object sender, KeyRoutedEventArgs e)
    {
        if (e.Key == Windows.System.VirtualKey.Enter)
            await RegisterAsync();
    }

    private async void RegisterButton_Click(object sender, RoutedEventArgs e) => await RegisterAsync();

    private void BackLink_Click(object sender, RoutedEventArgs e) =>
        Frame.Navigate(typeof(LoginPage), UserBox.Text);

    private async Task RegisterAsync()
    {
        var user = UserBox.Text;

        var error = Validator.ValidateNewAccount(user, PassBox.Password, ConfirmBox.Password);
        if (error != null)
        {
            ShowError(error);
            return;
        }

        UserService.Register(user, PassBox.Password);

        var dialog = new ContentDialog
        {
            XamlRoot = XamlRoot,
            Title = "¡Cuenta creada!",
            Content = $"Ya puedes iniciar sesión como \"{user}\".",
            CloseButtonText = "Ir al login"
        };
        await dialog.ShowAsync();

        Frame.Navigate(typeof(LoginPage), user);
    }

    private void ShowError(string message)
    {
        ErrorText.Text = message;
        ErrorText.Visibility = Visibility.Visible;
    }
}
