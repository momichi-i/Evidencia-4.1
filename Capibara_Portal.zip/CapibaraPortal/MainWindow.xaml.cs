using Microsoft.UI.Xaml;

namespace CapibaraPortal;

public sealed partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
        Title = "Universidad Capibara - Portal de estudiantes";
        AppWindow.Resize(new Windows.Graphics.SizeInt32(520, 720));
        RootFrame.Navigate(typeof(LoginPage));
    }
}
