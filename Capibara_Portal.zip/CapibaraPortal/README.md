# Portal de estudiantes - Universidad Capibara (WinUI 3)

Aplicación WinUI 3 de escritorio con login y registro.

## Cómo abrirlo
1. Visual Studio 2022 con la carga de trabajo **Desarrollo de la plataforma universal de Windows / Desarrollo de escritorio de .NET** y el componente **Windows App SDK C# Templates**.
2. Archivo > Abrir > Proyecto o solución > `CapibaraPortal.csproj`.
3. Elige la plataforma **x64** y presiona **F5**.

## Qué hace
- **Login**: usuario + contraseña. No permite espacios en ninguno de los dos.
- Si el usuario **no existe**, pregunta si quieres crear una cuenta nueva y te lleva al registro.
- **Registro**: usuario (mín. 3), contraseña (mín. 4) y confirmación. Valida que no haya espacios ni usuarios repetidos.
- Tras entrar, una pantalla de bienvenida con botón de cerrar sesión.

## Estructura
| Archivo | Función |
|---|---|
| `MainWindow` | Ventana con un `Frame` que navega entre páginas |
| `LoginPage` | Formulario de inicio de sesión |
| `RegisterPage` | Formulario de nueva cuenta |
| `HomePage` | Pantalla de bienvenida |
| `UserService.cs` | Guarda usuarios en `%LocalAppData%\CapibaraPortal\usuarios.json` (contraseña con hash PBKDF2 + sal) |
| `Validator.cs` | Reglas de validación (sin espacios, longitudes, coincidencia) |
