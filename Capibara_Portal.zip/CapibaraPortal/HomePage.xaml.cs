using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Navigation;

namespace CapibaraPortal;

public sealed partial class HomePage : Page
{
    public HomePage()
    {
        InitializeComponent();
    }

    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        var user = e.Parameter as string ?? "estudiante";
        WelcomeText.Text = $"¡Bienvenido, {user}!";
    }

    private void LogoutButton_Click(object sender, RoutedEventArgs e) =>
        Frame.Navigate(typeof(LoginPage));
}
