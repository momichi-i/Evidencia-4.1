namespace CapibaraPortal;

/// <summary>Reglas de validación compartidas por el login y el registro.</summary>
public static class Validator
{
    public const int MinUserLength = 3;
    public const int MinPasswordLength = 4;

    public static bool HasWhitespace(string text) => text.Any(char.IsWhiteSpace);

    /// <summary>Devuelve un mensaje de error, o null si todo está bien.</summary>
    public static string? ValidateNewAccount(string user, string pass, string confirm)
    {
        if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass) || string.IsNullOrEmpty(confirm))
            return "Completa todos los campos.";

        if (HasWhitespace(user) || HasWhitespace(pass) || HasWhitespace(confirm))
            return "El usuario y la contraseña no pueden tener espacios.";

        if (user.Length < MinUserLength)
            return $"El usuario debe tener al menos {MinUserLength} caracteres.";

        if (pass.Length < MinPasswordLength)
            return $"La contraseña debe tener al menos {MinPasswordLength} caracteres.";

        if (pass != confirm)
            return "Las contraseñas no coinciden.";

        if (UserService.Exists(user))
            return "Ese usuario ya existe. Elige otro.";

        return null;
    }
}
