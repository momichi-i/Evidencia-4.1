using System.Security.Cryptography;
using System.Text.Json;

namespace CapibaraPortal;

public enum LoginResult
{
    Success,
    UserNotFound,
    WrongPassword
}

/// <summary>
/// Guarda los usuarios en un archivo JSON local (%LocalAppData%\CapibaraPortal\usuarios.json).
/// Las contraseñas NO se guardan en texto plano: se guarda un hash PBKDF2 con sal.
/// </summary>
public static class UserService
{
    private const int Iterations = 100_000;

    private class StoredUser
    {
        public string Salt { get; set; } = "";
        public string Hash { get; set; } = "";
    }

    private static readonly string FilePath = Path.Combine(
        Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "CapibaraPortal", "usuarios.json");

    private static readonly Dictionary<string, StoredUser> Users = Load();

    public static bool Exists(string user) => Users.ContainsKey(user);

    public static bool Register(string user, string password)
    {
        if (Exists(user)) return false;

        var salt = RandomNumberGenerator.GetBytes(16);
        Users[user] = new StoredUser
        {
            Salt = Convert.ToBase64String(salt),
            Hash = Convert.ToBase64String(ComputeHash(password, salt))
        };
        Save();
        return true;
    }

    public static LoginResult Validate(string user, string password)
    {
        if (!Users.TryGetValue(user, out var stored))
            return LoginResult.UserNotFound;

        var salt = Convert.FromBase64String(stored.Salt);
        var expected = Convert.FromBase64String(stored.Hash);
        var actual = ComputeHash(password, salt);

        return CryptographicOperations.FixedTimeEquals(expected, actual)
            ? LoginResult.Success
            : LoginResult.WrongPassword;
    }

    private static byte[] ComputeHash(string password, byte[] salt) =>
        Rfc2898DeriveBytes.Pbkdf2(password, salt, Iterations, HashAlgorithmName.SHA256, 32);

    private static Dictionary<string, StoredUser> Load()
    {
        var result = new Dictionary<string, StoredUser>(StringComparer.OrdinalIgnoreCase);
        try
        {
            if (File.Exists(FilePath))
            {
                var data = JsonSerializer.Deserialize<Dictionary<string, StoredUser>>(File.ReadAllText(FilePath));
                if (data != null)
                    foreach (var pair in data) result[pair.Key] = pair.Value;
            }
        }
        catch
        {
            // Si el archivo está dañado se empieza con una lista vacía.
        }
        return result;
    }

    private static void Save()
    {
        Directory.CreateDirectory(Path.GetDirectoryName(FilePath)!);
        File.WriteAllText(FilePath, JsonSerializer.Serialize(Users, new JsonSerializerOptions { WriteIndented = true }));
    }
}
