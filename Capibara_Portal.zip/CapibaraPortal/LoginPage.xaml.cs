using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Navigation;

namespace CapibaraPortal;

public sealed partial class LoginPage : Page
{
    public LoginPage()
    {
        InitializeComponent();
    }

    // Si venimos del registro, el usuario llega ya escrito.
    protected override void OnNavigatedTo(NavigationEventArgs e)
    {
        if (e.Parameter is string user && !string.IsNullOrEmpty(user))
            UserBox.Text = user;
    }

    // Bloquea los espacios mientras se escribe el usuario.
    private void NoSpaces_BeforeTextChanging(TextBox sender, TextBoxBeforeTextChangingEventArgs args)
    {
        if (Validator.HasWhitespace(args.NewText))
            args.Cancel = true;
    }

    // La contraseña no se puede filtrar al escribir, así que se avisa en pantalla.
    private void PassBox_PasswordChanged(object sender, RoutedEventArgs e)
    {
        if (Validator.HasWhitespace(PassBox.Password))
            ShowError("La contraseña no puede tener espacios.");
        else
            HideError();
    }

    private async void Field_KeyDown(object sender, KeyRoutedEventArgs e)
    {
        if (e.Key == Windows.System.VirtualKey.Enter)
            await TryLoginAsync();
    }

    private async void LoginButton_Click(object sender, RoutedEventArgs e) => await TryLoginAsync();

    private void RegisterLink_Click(object sender, RoutedEventArgs e) =>
        Frame.Navigate(typeof(RegisterPage), UserBox.Text);

    private async Task TryLoginAsync()
    {
        var user = UserBox.Text;
        var pass = PassBox.Password;

        if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass))
        {
            ShowError("Escribe tu usuario y tu contraseña.");
            return;
        }

        if (Validator.HasWhitespace(user) || Validator.HasWhitespace(pass))
        {
            ShowError("El usuario y la contraseña no pueden tener espacios.");
            return;
        }

        switch (UserService.Validate(user, pass))
        {
            case LoginResult.Success:
                Frame.Navigate(typeof(HomePage), user);
                break;

            case LoginResult.WrongPassword:
                ShowError("Contraseña incorrecta.");
                PassBox.Password = "";
                break;

            case LoginResult.UserNotFound:
                await AskToRegisterAsync(user);
                break;
        }
    }

    private async Task AskToRegisterAsync(string user)
    {
        LoginButton.IsEnabled = false;

        var dialog = new ContentDialog
        {
            XamlRoot = XamlRoot,
            Title = "Cuenta no encontrada",
            Content = $"No existe una cuenta con el usuario \"{user}\".\n¿Quieres crear una nueva?",
            PrimaryButtonText = "Crear cuenta",
            CloseButtonText = "Cancelar",
            DefaultButton = ContentDialogButton.Primary
        };

        var result = await dialog.ShowAsync();
        LoginButton.IsEnabled = true;

        if (result == ContentDialogResult.Primary)
            Frame.Navigate(typeof(RegisterPage), user);
    }

    private void ShowError(string message)
    {
        ErrorText.Text = message;
        ErrorText.Visibility = Visibility.Visible;
    }

    private void HideError() => ErrorText.Visibility = Visibility.Collapsed;
}
